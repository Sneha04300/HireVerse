import { useState, useRef, useCallback, useEffect } from "react";

export default function useSpeechRecognition() {
  const [interimText, setInterimText] = useState("");
  const [finalText, setFinalText] = useState("");
  const [isListening, setIsListening] = useState(false);
  const [error, setError] = useState(null);

  const recognitionRef = useRef(null);
  const finalRef = useRef("");
  const isActiveRef = useRef(false);

  const isSupported = !!(
    window.SpeechRecognition || window.webkitSpeechRecognition
  );

   const start = useCallback(() => {
  if (!isSupported) {
    setError("Speech recognition is not supported in this browser.");
    return;
  }

  // Stop any previous recognition instance
  if (recognitionRef.current) {
    try {
      recognitionRef.current.stop();
    } catch (e) {
      console.log(e);
    }

    recognitionRef.current = null;
  }

  const SpeechRecognition =
    window.SpeechRecognition || window.webkitSpeechRecognition;

    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = true;
    recognition.maxAlternatives = 1;
    recognition.lang = "en-US";
    recognition.serviceURI = "";
recognition.maxAlternatives = 5;

    recognition.onstart = () => {
      console.log("Recognition Started");
      setIsListening(true);
      setError(null);
    };

    recognition.onerror = (event) => {
  console.log("Recognition Error:", event.error);

  if (event.error === "no-speech") {
    // Ignore this and let onend restart recognition.
    return;
  }

  if (event.error === "audio-capture") {
    setError("No microphone detected.");
    return;
  }

  if (event.error === "not-allowed") {
    setError("Microphone permission denied.");
    return;
  }

  setError(event.error);
};

    recognition.onend = () => {
  console.log("Recognition Ended");

  setIsListening(false);
  recognitionRef.current = null;

  if (isActiveRef.current) {
    setTimeout(() => {
      start();
    }, 300);
  }
};

    recognition.onresult = (event) => {
      let interim = "";
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const result = event.results[i];
        const transcript = result[0].transcript;
        if (result.isFinal) {
          finalRef.current += (finalRef.current ? " " : "") + transcript;
        } else {
          interim += transcript;
        }
      }
      console.log("Recognition Result", finalRef.current, interim);
      setFinalText(finalRef.current);
      setInterimText(interim);
    };

    console.log("Calling recognition.start()");
    isActiveRef.current = true;
    try {
      recognition.start();
      recognitionRef.current = recognition;
    } catch (e) {
      console.error("recognition.start() threw:", e);
      recognitionRef.current = null;
      setError(`Speech recognition failed: ${e.message}`);
    }
  }, [isSupported]);

  const stop = useCallback(() => {
    isActiveRef.current = false;
    if (recognitionRef.current) {
      recognitionRef.current.stop();
      recognitionRef.current = null;
    }
    setIsListening(false);
  }, []);

  const resetTranscript = useCallback(() => {
    finalRef.current = "";
    setFinalText("");
    setInterimText("");
  }, []);

  useEffect(() => {
    return () => {
      isActiveRef.current = false;
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, []);

  return {
    interimText,
    finalText,
    isListening,
    error,
    isSupported,
    start,
    stop,
    resetTranscript,
  };
}
